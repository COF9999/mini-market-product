package com.api_rest.items_db_II;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemsDbIiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemsDbIiApplication.class, args);
	}

}
